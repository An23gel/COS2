# case-opening-simulator-2-script

cool script for the game but got complicated after having like 3 scripts
